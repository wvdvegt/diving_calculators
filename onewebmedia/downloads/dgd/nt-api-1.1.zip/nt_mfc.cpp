///////////////////////////////
// Name:    WinNT MFC Wrapper
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      WinNT Only
///////////////////////////////
//
// Description
// -----------
// This Kfun adds a interface to the winNT eventlog where security,
// alpplication and system log messages are stored for later analysis
// It provides a way to store info that can only be read by someone
// autorized on the NT system (i.e. an Admin or Domain Admin).
//
// It can be used to store security alerts like people trying to 
// upgrade their level illegally, start/shutdown/restart times of 
// the mud and some other info thats handy to log but is not required 
// to be accessed from within the mud.
//
// This file also add some functions that enable the rest of dgd to 
// link with the mfc part.
//
///////////////////////////////
// event types
// -----------------------------    -------------------
// EVENTLOG_ERROR_TYPE              Error event
// EVENTLOG_WARNING_TYPE            Warning event
// EVENTLOG_INFORMATION_TYPE        Information event
// EVENTLOG_AUDIT_SUCCESS           Success Audit event (not supported by dgd)
// EVENTLOG_AUDIT_FAILURE           Failure Audit event (not supported by dgd)
// -----------------------------    -------------------
///////////////////////////////

# include "..\host\pc\stdafx.h"

# include <windows.h>
# include <winbase.h>

# include <lmcons.h>
# include <lmmsg.h>

# include <stdio.h>
# include <process.h>
# include <tchar.h>

extern "C" {
    # include "dgd.h"
    # undef exit
}

//start of some tricks to force the linker to link the mfc with the non-mfc part
void AddToMessageLog(DWORD eventID,LPTSTR lpszMsg);

extern "C" {
    void addtomessagelog(DWORD eventID,char *lpszMsg) {
        AddToMessageLog(eventID,lpszMsg);
    }
}

//end   of some tricks to force the linker to link the mfc with the non-mfc part

void AddToMessageLog(DWORD eventID,LPTSTR lpszMsg)
{
    HKEY   hk;
    DWORD  dwData;
    CHAR   *szBuf;

    // Add your source name as a subkey under the Application
    // key in the EventLog service portion of the registry. 
    szBuf=(char *)malloc(1024);
    strcpy(szBuf,"SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\");
    strcat(szBuf,AfxGetApp()->m_pszExeName); //append dgd

    if (RegCreateKey(HKEY_LOCAL_MACHINE,
                     szBuf,
                     &hk)) {
        P_message("Could not create registry key for NT eventlog service\012");
    }

    // Set the Event ID message-file name.
    //
    GetModuleFileName(GetModuleHandle(NULL),szBuf,1024-1); //returns full path+filename of dgd.exe
    
    // Add the Event ID message-file name to the subkey.
    //
    if (RegSetValueEx(  hk,                         // subkey handle         
                        "EventMessageFile",         // value name            
                        0,                          // must be zero          
                        REG_EXPAND_SZ,              // value type            
                        (LPBYTE) szBuf,             // address of value data 
                        strlen(szBuf)+1))     {     // length of value data  
        P_message("Could not set NT eventlog message file\012");
    }
    free(szBuf);

    // Set the supported types flags.
    //
    dwData =    EVENTLOG_ERROR_TYPE | 
                EVENTLOG_WARNING_TYPE |
                EVENTLOG_INFORMATION_TYPE;

    if (RegSetValueEx(  hk,                 // subkey handle                
                        "TypesSupported",   // value name                   
                        0,                  // must be zero                 
                        REG_DWORD,          // value type                   
                        (LPBYTE) &dwData,   // address of value data        
                        sizeof(DWORD))) {   // length of value data         
        P_message("Could not set NT eventlog supported types\012");
    }

    RegCloseKey(hk);

    // Now dump the message!
    //
    HANDLE  hEventSource;
    LPCSTR  lpszStrings[2];
    LPCSTR  *lpsztmp;
    WORD    eventTYPE;

    // Use event logging to log the error.
    //
    hEventSource = RegisterEventSource(NULL, TEXT(AfxGetApp()->m_pszExeName));

    // Little workaround to get string types to match.
    //
    lpszStrings[0] = lpszMsg;
    lpszStrings[1] = "";
    lpsztmp        = lpszStrings;

//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+

    switch (eventID >> 30) { 
        case 0: 
            eventTYPE=0; //success
            break;
        case 1: 
            eventTYPE=4; //informational
            break;
        case 2: 
            eventTYPE=2; //warning
            break;
        case 3: 
            eventTYPE=1; //error
            break;
    }

    // Send the eventmessage itself to the WinNT application eventlog
    if (hEventSource != NULL) {
                ReportEvent(hEventSource,               // handle of event source
                            eventTYPE,                  // event type (coded in mc file)
                            0,                          // event category
                            eventID,                    // event ID
                            NULL,                       // current user's SID
                            1,                          // strings in lpszStrings
                            0,                          // no bytes of raw data
                            lpsztmp,                    // array of error strings
                            NULL);                      // no raw data

    (VOID) DeregisterEventSource(hEventSource);
    } else {
        P_message("Could not register NT eventlog source\012");
    }
}

/*
 * AnsiToUnicode converts the ANSI string pszA to a Unicode string
 * and returns the Unicode string through ppszW. Space for the
 * the converted string is allocated by AnsiToUnicode.
 */
HRESULT __fastcall AnsiToUnicode(LPCSTR pszA, LPWSTR* ppszW)
{
    ULONG cCharacters;
    DWORD dwError;
 
    // If input is null then just return the same.
    if (NULL == pszA)
    {
        *ppszW = NULL;
        return NOERROR;
    }
 
    // Determine number of wide characters to be allocated for the
    // Unicode string. Don't forget to free it after use
    cCharacters =  strlen(pszA)+1;
 
    *ppszW = (LPWSTR) malloc(cCharacters*2);
    if (NULL == *ppszW)
        return E_OUTOFMEMORY;
 
    // Covert to Unicode.
    if (0 == MultiByteToWideChar(   CP_ACP, 
                                    0, 
                                    pszA, 
                                    cCharacters,
                                    *ppszW, 
                                    cCharacters))
    {
        dwError = GetLastError();
        free(*ppszW);
        *ppszW = NULL;
        return HRESULT_FROM_WIN32(dwError);
    }
 
    return NOERROR;
}

//start of some tricks to force the linker to link the mfc with the non-mfc part
int NetMessageSend(char *buf,char *srv,char *usr);

extern "C" {
    int netmessagesend(char *buf,char *srv,char *usr) {
        return NetMessageSend(buf,srv,usr);
    }
}

//end   of some tricks to force the linker to link the mfc with the non-mfc part

int NetMessageSend(char *buf,char *srv,char *usr) {
    
    LPWSTR ucbuf;
    LPWSTR ucsrv;
    LPWSTR ucusr;

    NET_API_STATUS  err;

    AnsiToUnicode(buf,&ucbuf);
    AnsiToUnicode(srv,&ucsrv);
    AnsiToUnicode(usr,&ucusr);

    //add a new alias on the target machine
    err=NetMessageNameAdd(ucsrv,ucusr);
    if (!err) {
        //send a message to it
        err=NetMessageBufferSend(ucsrv,ucusr,NULL,(LPBYTE)ucbuf,2*wcslen(ucbuf));
        
        //remove alias from machine
        if (!err) {
            err=NetMessageNameDel(ucsrv,ucusr); 
        } else {
            NetMessageNameDel(ucsrv,ucusr);
        }
    }

    //free memory allocated by AnsiToUnicode
    free(ucbuf);
    free(ucsrv);
    free(ucusr);

    return err;
}
