//to be used for information
//
//  Values are 32 bit values layed out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: dgd_evt_plain
//
// MessageText:
//
//  %1
//
#define dgd_evt_plain                    0x00000000L

//to be used for information
//
// MessageId: dgd_evt_informs
//
// MessageText:
//
//  DGD informs you that %1
//
#define dgd_evt_informs                  0x40000001L

//to be used for reporting errors
//
// MessageId: dgd_evt_reports
//
// MessageText:
//
//  DGD reports you that %1
//
#define dgd_evt_reports                  0x80000002L

//to be used for security alerts
//
// MessageId: dgd_evt_alerts
//
// MessageText:
//
//  DGD alerts you that %1
//
#define dgd_evt_alerts                   0xC0000003L

//to be used for dgd started ok
//
// MessageId: dgd_evt_starts
//
// MessageText:
//
//  DGD started by %1
//
#define dgd_evt_starts                   0x40000004L

//to be used for dgd stopped ok
//
// MessageId: dgd_evt_stops
//
// MessageText:
//
//  DGD stopped by %1
//
#define dgd_evt_stops                    0x40000005L

