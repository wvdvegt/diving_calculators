/* MessageText:

   DGD informs you that %1
*/
#define dgd_evt_informs                  0x40000001
/* MessageText:

   DGD reports you that %1
*/
#define dgd_evt_reports                  0x80000002
/* MessageText:

    DGD alerts you that %1
*/
#define dgd_evt_alerts                   0xC0000003
/* MessageText:

    DGD started by %1
*/
#define dgd_evt_starts                   0x00000004
/* MessageText:

    DGD stopped by %1
*/
#define dgd_evt_stops                    0x00000005

