///////////////////////////////
// Name:    WinNT MFC Wrapper
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      WinNT Only
///////////////////////////////

extern void addtomessagelog(DWORD eventID,char *lpszMsg);
extern int netmessagesend(char *buf,char *srv,char *usr);