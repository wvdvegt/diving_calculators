///////////////////////////////
// Name:    kfuns for winNT
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      WinNT Only
///////////////////////////////
//
// For more documentation on parameters passed and exact
// nature of the kernel functions wrapped by these kfuns
// just look them up in the msvc help files on win32 
// programming. Constant definitions can be found in the 
// header files distributed with msvc 4.x
// 
///////////////////////////////
//
//  functions wrapped               platform    remarks
//  ------------------------------  ----------- --------------------------
//  ReportEvent                     NT only     Interface to winNT eventlog
//  ------------------------------  ----------- --------------------------
//  NetMessageBufferSend            NT only     Interface to winNT 
//                                              Messenger Service (and 
//                                              WinPopUp)
//  ------------------------------  ----------- --------------------------
//
///////////////////////////////

# ifndef FUNCDEF
 # include "dgd.h"
 # include "str.h"
 # include "array.h"
 # include "object.h"
 # include "xfloat.h"
 # include "interpret.h"

 # include "nt_api.h"
# endif


# ifdef FUNCDEF
FUNCDEF("logevent", kf_logevent, pt_logevent)
# else
char pt_logevent[] = { C_TYPECHECKED | C_STATIC, T_VOID, 2, T_INT, T_STRING };

/*
 * NAME:        kfun->logevent(event_id,event_msg);
 * DESCRIPTION: Lets dgd write an entry in the filelog
 * WRAPS:       BOOL ReportEvent(   HANDLE hEventLog,   // handle returned by RegisterEventSource 
 *                                  WORD wType,         // event type to log 
 *                                  WORD wCategory,     // event category 
 *                                  DWORD dwEventID,    // event identifier 
 *                                  PSID lpUserSid,     // user security identifier (optional) 
 *                                  WORD wNumStrings,   // number of strings to merge with message  
 *                                  DWORD dwDataSize,   // size of binary data, in bytes
 *                                  LPCTSTR *lpStrings, // array of strings to merge with message 
 *                                  LPVOID lpRawData    // address of binary data 
 *                               );
 * RETURNS:     0
 */
int kf_logevent(nargs)
int nargs;
{
    char         *evmsg;
    DWORD         evid;
    
    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
        case 1:
            return -1;
        case 2:
            break;
        default :
            return nargs;
    }

    //get things from call stack
    evid   =sp[1].u.number;
    evmsg  =sp[0].u.string->text;

    //do the actual call to the NT kernel
    addtomessagelog(evid,evmsg);
    
    //cleanup the call stack
    str_del((sp++)->u.string);
    
    //return 0
    sp->type     = T_INT;
    sp->u.number = 0;
    return 0;
}
# endif


# ifdef FUNCDEF
FUNCDEF("netmessage", kf_netmessage, pt_netmessage)
# else
char pt_netmessage[] = { C_TYPECHECKED | C_STATIC, T_VOID, 3, T_STRING, T_STRING, T_STRING };

/*
 * NAME:        kfun->netmessage();
 * DESCRIPTION: Lets dgd send a pop-up message to another computer
 *              in the WinNT network. 
 *              The LANman API used is in Unicode.
 * WRAPS:       NET_API_STATUS NetMessageBufferSend(LPTSTR servername,  
 *                                                  LPTSTR msgname, 
 *                                                  LPTSTR fromname,    
 *                                                  LPBYTE buf, 
 *                                                  DWORD buflen    
 *                                                  ); 
 * RETURNS:     
 */
int kf_netmessage(nargs)
int nargs;
{   

LPTSTR          buf;
LPTSTR          srv;
LPTSTR          usr;
NET_API_STATUS  err;


    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
        case 1:
        case 2:
            return -1;
        case 3:
            break;
        default :
            return nargs;
    }

    //get things from call stack
    buf=sp[2].u.string->text;
    srv=sp[1].u.string->text;
    usr=sp[0].u.string->text;

    //do the actual call to the NT kernel
    err=netmessagesend(buf,srv,usr);
    
    //cleanup the call stack
    //cleanup the call stack
    str_del((sp++)->u.string);
    str_del((sp++)->u.string);
    str_del(sp->u.string);

    //return 0
    sp->type     = T_INT;
    sp->u.number = err;
    return 0;
}
#endif