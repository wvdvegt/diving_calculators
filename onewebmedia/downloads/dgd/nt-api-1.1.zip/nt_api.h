///////////////////////////////
// Name:    WinNT MFC Wrapper
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      WinNT Only
///////////////////////////////

//contains includes for access to bare win32 functions

#include <windows.h>
#include <winbase.h>
#include <lmcons.h>
#include <lmmsg.h>

//contain the ID's of the insertion messages
#include "dgd_event.h"

//comtain code to link mfc part with non-mfc part of dgd
#include "95_mfc.h"
#include "nt_mfc.h"
