;//to be used for information
MessageId=0
SymbolicName=dgd_evt_plain
Severity=Success
Language=English
%1
.

;//to be used for information
MessageId=1
SymbolicName=dgd_evt_informs
Severity=Informational
Language=English
DGD informs you that %1
.

;//to be used for reporting errors
MessageId=2
SymbolicName=dgd_evt_reports
Severity=Warning
Language = English
DGD reports you that %1
.

;//to be used for security alerts
MessageId=3
SymbolicName=dgd_evt_alerts
Severity=Error
Language=English
DGD alerts you that %1
.

;//to be used for dgd started ok
MessageId=4
SymbolicName=dgd_evt_starts
Severity=Informational
Language=English
DGD started by %1
.
;//to be used for dgd stopped ok
MessageId=5
SymbolicName=dgd_evt_stops
Severity=Informational
Language=English
DGD stopped by %1
.
