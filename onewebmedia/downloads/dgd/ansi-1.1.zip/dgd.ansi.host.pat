*** host.noansi.h   Tue Apr 15 13:00:45 1997
--- host.h   Tue Apr 15 13:00:45 1997
***************
*** 273,279 ****
--- 273,280 ----
  # define HT   '\011'
  # define LF   '\012'
  # define VT   '\013'
  # define FF   '\014'
  # define CR   '\015'
+ # define ESC  '\033'
  
  # define ALGN(x, s)   (((x) + (s) - 1) & ~((s) - 1))
