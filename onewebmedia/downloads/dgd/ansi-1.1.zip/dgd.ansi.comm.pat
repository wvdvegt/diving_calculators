*** comm.noansi.c   Tue Apr 15 13:00:45 1997
--- comm.c  Tue Apr 15  14:31:41 1997
***************
*** 289,299 ****
        /*
         * insert CR before LF
         */
        *q++ = LF;
        size++;
!   } else if ((*p & 0x7f) < ' ' && *p != HT && *p != BEL && *p != BS) {
        /*
         * illegal character
         */
        p++;
        --len;
--- 289,299 ----
        /*
         * insert CR before LF
         */
        *q++ = CR;
        size++;
!   } else if ((*p & 0x7f) < ' ' && *p != HT && *p != BEL && *p != BS && *p != ESC) {
        /*
         * illegal character
         */
        p++;
        --len;
