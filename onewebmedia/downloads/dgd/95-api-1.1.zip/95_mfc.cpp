///////////////////////////////
// Name:    Win95 MFC Wrapper
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      Win95/WinNT
///////////////////////////////
//
// This file add some functions that enable the rest of dgd to 
// link with the mfc part.
//
///////////////////////////////

# include "..\host\pc\stdafx.h"

extern "C" {

    # include "dgd.h"
    # undef exit

    //return the ini file name for this exe file
    const char *GetProfileName() {
        return AfxGetApp()->m_pszProfileName;
    }
    
    //return the full exe file name (including path)
    const char *GetExeName() {
        return AfxGetApp()->m_pszExeName;
    }
}

//end   of some tricks to force the linker to link the mfc with the non-mfc part

