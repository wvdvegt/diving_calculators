///////////////////////////////
// Name:    Win95 95/MFC Wrapper
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      Win95/WinNT
///////////////////////////////
//
// This file add some functions that enable the rest of dgd to 
// link with the mfc part.
//
///////////////////////////////

extern char *GetProfileName();
extern char *GetExeName();
