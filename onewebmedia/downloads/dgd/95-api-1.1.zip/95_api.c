///////////////////////////////
// Name:    kfuns for win95
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      Win95/WinNT
///////////////////////////////
//
// For more documentation on parameters passed and exact
// nature of the kernel functions wrapped by these kfuns
// just look them up in the msvc help files on win32 
// programming. Constant definitions can be found in the 
// header files distributed with msvc 4.x
//
///////////////////////////////
// 
//  functions wrapped               platform    remarks
//  ------------------------------  ----------- --------------------------
//  GetPrivateprofileInt            95/NT       win95 & winNT differ in 
//  GetPrivateprofileString         95/NT       where the information
//  GetProfileInt                   95/NT       of these functions
//  GetProfileString                95/NT       is stored (file or registry).
//  ------------------------------  ----------- --------------------------
//  GetOsVersion                    95/NT       Returns the OS version of the server
//  MessageBeep                     95/NT       Pages the operator
//  ------------------------------  ----------- --------------------------
//
///////////////////////////////


# ifndef FUNCDEF
 # include "dgd.h"
 # include "str.h"
 # include "array.h"
 # include "object.h"
 # include "xfloat.h"
 # include "interpret.h"
 # include "95_api.h"
# endif

# ifdef FUNCDEF
FUNCDEF("getprofileint", kf_getprofileint, pt_getprofileint)
# else
char pt_getprofileint[] = { C_TYPECHECKED | C_STATIC, T_INT, 2, T_STRING, T_STRING };

/*
 * NAME:        kfun->getprofileint(section,entry);
 * DESCRIPTION: read an int from either <%systemroot%>win.ini or the registry
 *              key KEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\IniFileMapping\win.ini
 * WRAPS:       UINT GetProfileInt( LPCTSTR lpAppName,  // address of section name 
 *                                  LPCTSTR lpKeyName,  // address of key name 
 *                                  INT nDefault        // default value if key name is not found 
 *                                );

 * RETURNS:     0 when entry not found or malformed else the actual value of the entry
 */
int kf_getprofileint(nargs)
int nargs;
{
    unsigned short len;
    char *section, *entry;
    
    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
        case 1:
            return -1;
        case 2:
            break;
        default:
            return nargs;
    }

    //get things from call stack
    section=sp[1].u.string->text;
    entry  =sp[0].u.string->text;

    //do the actual call to the NT kernel (use ANSI charset)
    len=GetProfileIntA(section,entry,0);

    //cleanup the call stack
    str_del((sp++)->u.string);
    str_del(sp->u.string);

    //return the retrieved int
    sp->type = T_INT;
    sp->u.number = len;
    return 0;
}
# endif


# ifdef FUNCDEF
FUNCDEF("getprofilestring", kf_getprofilestring, pt_getprofilestring)
# else
char pt_getprofilestring[] = { C_TYPECHECKED | C_STATIC, T_STRING, 3, T_STRING, T_STRING, T_STRING };

/*
 * NAME:        kfun->getprofilestring(section,entry,default);
 * DESCRIPTION: read an string from either <%systemroot%>win.ini or the registry
 *              key KEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\IniFileMapping\win.ini
 * WRAPS:       DWORD GetProfileString( LPCTSTR lpAppName,      // address of section name 
 *                                      LPCTSTR lpKeyName,      // address of key name 
 *                                      LPCTSTR lpDefault,      // address of default string 
 *                                      LPTSTR lpReturnedString,// address of destination buffer 
 *                                      DWORD nSize             // size of destination buffer 
 *                                    );
 * RETURNS:     default when entry not found else the actual value of the entry
 */
int kf_getprofilestring(nargs)
int nargs;
{
    unsigned long len;
    char *section, *entry, *deflt, *bufptr;
    char buf[256];
    bufptr=(char *)&buf;

    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
        case 1:
        case 2:
            return -1;
        case 3:
            break;
        default :
            return nargs;
    }

    //get things from call stack
    section=sp[2].u.string->text;
    entry  =sp[1].u.string->text;
    deflt  =sp[0].u.string->text;
        
    //do the actual call to the NT kernel (use ANSI charset)
    len=GetProfileStringA(section,entry,"",bufptr,sizeof(buf)-1);
    
    //cleanup the call stack
    str_del((sp++)->u.string);
    str_del((sp++)->u.string);
    str_del(sp->u.string);

    //return the retrieved string
    sp->type = T_STRING;
    str_ref(sp->u.string = str_new(bufptr, strlen(bufptr)));
    return 0;
}
# endif


# ifdef FUNCDEF
FUNCDEF("getprivateprofileint", kf_getprivateprofileint, pt_getprivateprofileint)
# else
char pt_getprivateprofileint[] = { C_TYPECHECKED | C_STATIC, T_INT, 2, T_STRING, T_STRING };

/*
 * NAME:        kfun->getprivateprofileint(section,entry);
 * DESCRIPTION: read an int from either dgd.ini or the registry
 *              key KEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\IniFileMapping\dgd.ini
 * WRAPS:       UINT GetPrivateProfileInt(  LPCTSTR lpAppName,  // address of section name
 *                                          LPCTSTR lpKeyName,  // address of key name
 *                                          INT nDefault,       // return value if key name is not found
 *                                          LPCTSTR lpFileName  // address of initialization filename
 *                                       );
 * RETURNS:     0 when entry not found or malformed else the actual value of the entry
 */
int kf_getprivateprofileint(nargs)
int nargs;
{
    unsigned short len;
    char *section, *entry;
    
    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
        case 1:
            return -1;
        case 2:
            break;
        default:
            return nargs;
    }

    //get things from call stack
    section=sp[1].u.string->text;
    entry  =sp[0].u.string->text;

    //do the actual call to the NT kernel, through nt_evt.cpp (use ANSI charset)
    len=GetPrivateProfileIntA(section,entry,0,GetProfileName());

    //cleanup the call stack
    str_del((sp++)->u.string);
    str_del(sp->u.string);

    //return the retrieved int
    sp->type = T_INT;
    sp->u.number = len;
    return 0;
}
# endif


# ifdef FUNCDEF
FUNCDEF("getprivateprofilestring", kf_getprivateprofilestring, pt_getprivateprofilestring)
# else
char pt_getprivateprofilestring[] = { C_TYPECHECKED | C_STATIC, T_STRING, 3, T_STRING, T_STRING, T_STRING };

/*
 * NAME:        kfun->getprivateprofilestring(section,entry,default);
 * DESCRIPTION: read an string from either dgd.ini or the registry
 *              key KEY_LOCAL_MACHINE\Software\Microsoft\Windows NT\CurrentVersion\IniFileMapping\dgd.ini
 * WRAPS:       DWORD GetPrivateProfileString(  LPCTSTR lpAppName,      // points to section name 
 *                                              LPCTSTR lpKeyName,      // points to key name 
 *                                              LPCTSTR lpDefault,      // points to default string 
 *                                              LPTSTR lpReturnedString,// points to destination buffer 
 *                                              DWORD nSize,            // size of destination buffer 
 *                                              LPCTSTR lpFileName      // points to initialization filename 
 *                                           );
 * RETURNS:     default when entry not found else the actual value of the entry
 */
int kf_getprivateprofilestring(nargs)
int nargs;
{
    unsigned long len;
    char *section, *entry, *deflt, *bufptr;
    char buf[256];
    bufptr=(char *)&buf;

    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
        case 1:
        case 2:
            return -1;
        case 3:
            break;
        default :
            return nargs;
    }

    //get things from call stack
    section=sp[2].u.string->text;
    entry  =sp[1].u.string->text;
    deflt  =sp[0].u.string->text;
        
    //do the actual call to the NT kernel, through nt_evt.cpp (use ANSI charset)
    len=GetPrivateProfileStringA(section,entry,"",bufptr,sizeof(buf)-1,GetProfileName());
    
    //cleanup the call stack
    str_del((sp++)->u.string);
    str_del((sp++)->u.string);
    str_del(sp->u.string);

    //return the retrieved string
    sp->type = T_STRING;
    str_ref(sp->u.string = str_new(bufptr, strlen(bufptr)));
    return 0;
}
# endif


# ifdef FUNCDEF
FUNCDEF("getosversion", kf_getosversion, pt_getosversion)
# else
char pt_getosversion[] = { C_TYPECHECKED | C_STATIC, T_STRING, 0, T_VOID };

/*
 * NAME:        kfun->getOSversion();
 * DESCRIPTION: get the version & build of the OS in string format
 * WRAPS:       BOOL GetVersionEx(LPOSVERSIONINFO lpVersionInformation);// pointer to version information structure
 * RETURNS:     returns the version of the OS as a string, including build number
 */
int kf_getosversion(nargs)
int nargs;
{
    OSVERSIONINFO Vi;
    char buf[256];
    char *bufptr;
    bufptr=(char *)&buf;
    
    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
            break;
        default:
            return nargs;
    }

    //do the actual call to the NT kernel (use ANSI charset)

    Vi.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
    GetVersionEx(&Vi);
    
/*  typedef struct _OSVERSIONINFO{  DWORD dwOSVersionInfoSize; 
 *                                  DWORD dwMajorVersion; 
 *                                  DWORD dwMinorVersion; 
 *                                  DWORD dwBuildNumber; 
 *                                  DWORD dwPlatformId;
 *                                  TCHAR szCSDVersion[ 128 ]; 
 *                              } OSVERSIONINFO; 
 */

    //return the retrieved string
    switch (Vi.dwPlatformId) {
    case VER_PLATFORM_WIN32s:
        //Win32s on Windows 3.1 
        sprintf(bufptr,"%s %d.%d","Windows",Vi.dwMajorVersion,Vi.dwMinorVersion);
        break;
    case VER_PLATFORM_WIN32_WINDOWS:
        //Win32 on Windows 95
        sprintf(bufptr,"%s %d.%d (build %d)","Windows 95",Vi.dwMajorVersion,Vi.dwMinorVersion,Vi.dwBuildNumber & 0xFFFF);
        break;
    case VER_PLATFORM_WIN32_NT:
        //Win32 on Windows NT.
        sprintf(bufptr,"%s %d.%d (build %d)","Windows NT",Vi.dwMajorVersion,Vi.dwMinorVersion,Vi.dwBuildNumber);
        break;
    default:
        sprintf(bufptr,"Unkown OS");
    }
    
    //cleanup the call stack   
    --sp;

    //return the created info as a string
    sp->type = T_STRING;
    str_ref(sp->u.string = str_new(bufptr, strlen(bufptr)));
    return 0;
}
# endif


# ifdef FUNCDEF
FUNCDEF("messagebeep", kf_messagebeep, pt_messagebeep)
# else
char pt_messagebeep[] = { C_TYPECHECKED | C_STATIC | C_VARARGS, T_INT, 1, T_INT };

/*
 * NAME:    kfun->messagebeep(sound);
 * DESCRIPTION: Generates a beep or plays a systemsound on the server.
 *              If sound is ommited, the standard beep is assumed.




 * WRAPS:       BOOL MessageBeep(UINT uType);   // sound type 
 * PARAMETER(s):uType   Specifies the sound type, as identified by an 
 *                      entry in the [sounds] section of the registry. 
 *                      This parameter can be one of the following values: 
 *
 *              Value               Sound
 *              ------------------- ----------------------------------------
 *              0xFFFFFFFF          Standard beep using the computer speaker
 *              MB_ICONASTERISK     SystemAsterisk
 *              MB_ICONEXCLAMATION  SystemExclamation
 *              MB_ICONHAND         SystemHand
 *              MB_ICONQUESTION     SystemQuestion
 *              MB_OK               SystemDefault
 *              ------------------- ----------------------------------------
 * RETURNS: Success or Failed
 */ 
int kf_messagebeep(nargs)
int nargs;
{
    long    sound;
    int     res;

    //check the number of parameters on the call stack
    switch (nargs) {
        case 0:
            (--sp)->type = T_INT;
            sp->u.number = 0xFFFFFFFF;
            break;
        case 1:
            break;
        default:
            return nargs;
    }

    //get things from call stack
    sound=sp->u.number;

    //do the actual call to the 95/NT kernel
    res=MessageBeep(sound);
    
    //cleanup the call stack
    
    //return the retrieved bool as int
    sp->type    =T_INT;
    sp->u.number=res;

    return 0;
}

# endif