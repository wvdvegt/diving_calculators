///////////////////////////////
// Name:    Win95 MFC Wrapper
// Version: 0.99
// Date     17-apr-97
// Author   Wim van der Vegt / Twoflower
// E-mail   wvd_vegt@knoware.nl
// Compiled:MSVC 4.2/5.0
// OS:      Win95/WinNT
///////////////////////////////

//contains includes for access to bare win32 functions

#include <windows.h>
#include <winbase.h>

#include "95_mfc.h"
