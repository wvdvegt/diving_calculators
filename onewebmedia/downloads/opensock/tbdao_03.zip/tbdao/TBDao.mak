# Microsoft Developer Studio Generated NMAKE File, Based on TBDao.dsp
!IF "$(CFG)" == ""
CFG=TBDao - Win32 Debug
!MESSAGE No configuration specified. Defaulting to TBDao - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "TBDao - Win32 Release" && "$(CFG)" != "TBDao - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "TBDao.mak" CFG="TBDao - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "TBDao - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "TBDao - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "TBDao - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : ".\TBDao.dll" "$(OUTDIR)\TBDao.tlb"

!ELSE 

ALL : ".\TBDao.dll" "$(OUTDIR)\TBDao.tlb"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\CRACK.OBJ"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\TBDao.obj"
	-@erase "$(INTDIR)\TBDao.pch"
	-@erase "$(INTDIR)\TBDao.res"
	-@erase "$(INTDIR)\TBDao.tlb"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\TBDao.exp"
	-@erase "$(OUTDIR)\TBDao.lib"
	-@erase ".\TBDao.dll"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MT /W4 /GX /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D\
 "_MBCS_AFXDLL" /Fp"$(INTDIR)\TBDao.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC_PROJ=/l 0x413 /fo"$(INTDIR)\TBDao.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TBDao.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /version:0.1 /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)\TBDao.pdb" /machine:I386 /def:".\TBDao.def" /out:"TBDao.dll"\
 /implib:"$(OUTDIR)\TBDao.lib" 
DEF_FILE= \
	".\TBDao.def"
LINK32_OBJS= \
	"$(INTDIR)\CRACK.OBJ" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\TBDao.obj" \
	"$(INTDIR)\TBDao.res"

".\TBDao.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "TBDao - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : ".\TBDao.dll" "$(OUTDIR)\TBDao.tlb"

!ELSE 

ALL : ".\TBDao.dll" "$(OUTDIR)\TBDao.tlb"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\CRACK.OBJ"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\TBDao.obj"
	-@erase "$(INTDIR)\TBDao.pch"
	-@erase "$(INTDIR)\TBDao.res"
	-@erase "$(INTDIR)\TBDao.tlb"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\TBDao.exp"
	-@erase "$(OUTDIR)\TBDao.lib"
	-@erase "$(OUTDIR)\TBDao.pdb"
	-@erase ".\TBDao.dll"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MDd /W4 /Gm /GX /Zi /Od /D "_DEBUG" /D "WIN32" /D "_WINDOWS"\
 /D "_MBCS" /D "_AFXDLL" /Fp"$(INTDIR)\TBDao.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
RSC_PROJ=/l 0x413 /fo"$(INTDIR)\TBDao.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TBDao.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /version:0.1 /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)\TBDao.pdb" /debug /machine:I386 /def:".\TBDao.def"\
 /out:"TBDao.dll" /implib:"$(OUTDIR)\TBDao.lib" 
DEF_FILE= \
	".\TBDao.def"
LINK32_OBJS= \
	"$(INTDIR)\CRACK.OBJ" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\TBDao.obj" \
	"$(INTDIR)\TBDao.res"

".\TBDao.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(CFG)" == "TBDao - Win32 Release" || "$(CFG)" == "TBDao - Win32 Debug"
SOURCE=.\CRACK.CPP
DEP_CPP_CRACK=\
	".\crack.h"\
	

"$(INTDIR)\CRACK.OBJ" : $(SOURCE) $(DEP_CPP_CRACK) "$(INTDIR)"\
 "$(INTDIR)\TBDao.pch"


SOURCE=.\StdAfx.cpp
DEP_CPP_STDAF=\
	".\StdAfx.h"\
	

!IF  "$(CFG)" == "TBDao - Win32 Release"

CPP_SWITCHES=/nologo /MT /W4 /GX /O2 /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D\
 "_MBCS_AFXDLL" /Fp"$(INTDIR)\TBDao.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\TBDao.pch" : $(SOURCE) $(DEP_CPP_STDAF)\
 "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TBDao - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W4 /Gm /GX /Zi /Od /D "_DEBUG" /D "WIN32" /D\
 "_WINDOWS" /D "_MBCS" /D "_AFXDLL" /Fp"$(INTDIR)\TBDao.pch" /Yc"stdafx.h"\
 /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\TBDao.pch" : $(SOURCE) $(DEP_CPP_STDAF)\
 "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\TBDao.cpp
DEP_CPP_TBDAO=\
	".\crack.h"\
	".\TBDao.h"\
	

"$(INTDIR)\TBDao.obj" : $(SOURCE) $(DEP_CPP_TBDAO) "$(INTDIR)"\
 "$(INTDIR)\TBDao.pch"


SOURCE=.\TBDao.odl

!IF  "$(CFG)" == "TBDao - Win32 Release"

MTL_SWITCHES=/nologo /D "NDEBUG" /tlb "$(OUTDIR)\TBDao.tlb" /mktyplib203 /o NUL\
 /win32 

"$(OUTDIR)\TBDao.tlb" : $(SOURCE) "$(OUTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TBDao - Win32 Debug"

MTL_SWITCHES=/nologo /D "_DEBUG" /tlb "$(OUTDIR)\TBDao.tlb" /mktyplib203 /o NUL\
 /win32 

"$(OUTDIR)\TBDao.tlb" : $(SOURCE) "$(OUTDIR)"
	$(MTL) @<<
  $(MTL_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\TBDao.rc
DEP_RSC_TBDAO_=\
	".\res\TBDao.rc2"\
	

!IF  "$(CFG)" == "TBDao - Win32 Release"


"$(INTDIR)\TBDao.res" : $(SOURCE) $(DEP_RSC_TBDAO_) "$(INTDIR)"
	$(RSC) /l 0x413 /fo"$(INTDIR)\TBDao.res" /i "Release" /d "NDEBUG" $(SOURCE)


!ELSEIF  "$(CFG)" == "TBDao - Win32 Debug"


"$(INTDIR)\TBDao.res" : $(SOURCE) $(DEP_RSC_TBDAO_) "$(INTDIR)"
	$(RSC) /l 0x413 /fo"$(INTDIR)\TBDao.res" /i "Debug" /d "_DEBUG" /d "_AFXDLL"\
 $(SOURCE)


!ENDIF 


!ENDIF 

