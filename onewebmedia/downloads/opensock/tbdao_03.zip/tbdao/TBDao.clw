; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
ODLFile=TBDao.odl
ClassCount=1
Class1=CTBDaoApp
LastClass=CTBDaoApp
NewFileInclude2=#include "TBDao.h"
ResourceCount=0
NewFileInclude1=#include "stdafx.h"

[CLS:CTBDaoApp]
Type=0
HeaderFile=TBDao.h
ImplementationFile=TBDao.cpp
Filter=N
