// DynaTable.h : main header file for the DYNATABLE DLL
//

#if !defined(AFX_DYNATABLE_H__B614BDE6_5DED_11D1_8A20_BE6E7F0D54B0__INCLUDED_)
#define AFX_DYNATABLE_H__B614BDE6_5DED_11D1_8A20_BE6E7F0D54B0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#define OK                   0	//success
#define WORKSPACENOTOPEN     1  //workspace not open
#define BUFFERSHORT          2  //string return buffer to small
#define NORECORDS            3	//no records found
#define ENDOFFILE            4	//end of file encountered
#define BEGINOFFILE          5  //begin of file encountered
#define INVALIDFIELDINDEX    6  //not a valid field index
#define NOTENDOFFILE         7  //not begin of file
#define NOTBEGINOFFILE       8  //not end of file
#define NOTSUPPORTED         9	//operation not supported
#define NOTOPEN              10 //database or recordset not open
#define UNKNOWNERROR		 11 //no dao errorinfo??
#define DAOEXCEPTION		 12 //dao exception encountered
#define OLEEXCEPTION		 13 //ole(variant) exception encountered
#define MEMEXCEPTION		 14 //memory exception encountered
#define OTHEREXCEPTION		 15 //other exception encountered
#define INVALIDDIRECTION	 16 //find direction invalid

/////////////////////////////////////////////////////////////////////////////
// CDynaTableApp
// See DynaTable.cpp for the implementation of this class
//

class CDynaTableApp : public CWinApp
{
public:
	CDynaTableApp();
	~CDynaTableApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDynaTableApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CDynaTableApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:    
	CDaoWorkspace		m_cDBEng;	//the master workspace
	CDaoDatabase*		p_cDbs;		//a database to open
	CDaoRecordset*		p_cRst;		//the recordset containing the query result
	COleVariant			m_cFld;		//needed for data exchange in/out of the recordset

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

/////////////////////////////////////////////////////////////////////////////
//
int DisplayDaoException(CDaoException* e);

#endif // !defined(AFX_DYNATABLE_H__B614BDE6_5DED_11D1_8A20_BE6E7F0D54B0__INCLUDED_)
