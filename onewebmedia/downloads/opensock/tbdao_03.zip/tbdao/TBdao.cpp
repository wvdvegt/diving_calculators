/////////////////////////////////////////////////////////////////
//	Project		: TBDAO, a connection between toolbook and 
//				  the doa v3.5 engine that wraps the microsoft
//				  Jet engine, thus enabling you to use
//				  Access databases and probeably through it's ODBC
//				  backdoor and access'es attached tables also 
//				  other/large relational databases like 
//				  SQL server & paradox. 
//	created by	: G.W. van der Vegt, 
//	e-mail		: vd_vegt@knoware.nl
//	homepage	: http://utopia.knoware.nl/users/wvd_vegt
//	date		: 24-may-1998
//	version		; 0.3
/////////////////////////////////////////////////////////////////
//
//  This dll shows how to interface toolbook directly to dao 3.5.
//	Major problem is that, altough you can query a database under
//	win95, it will refuse to update or append new records. WinNT4
//	doesn't have this problem.
//
//  It can be either linked statically or dynamically (shared)  
//	to mfc. For distribution the statically linked is preferred
//	(specially when you distribute a debug build) as the dll's
//	linked are rather new (mfc 4.2) and not present on all systems.
//
/////////////////////////////////////////////////////////////////
//
//	Tryout code to trip into the msvc or soft-ice debugger, 
//	they all refuse to work under win95 due to the fact that
//	toolbook is still a 16 bits app:
//
//	ASSERT(FALSE);
//	__asm int 3;
//	DebugBreak();
//
//  Under windows NT TRACEn Statements can be added to the Dll for 
//	debugging pruposes, but you have to compile the DBmon application
//  first that can be found between the msvc cd-rom samples.
//  OutputDebugString should also work then.
//
/////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TBdao.h"
#include "Crack.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define chSTR(x) #x
#define chSTR2(x) chSTR(x)
#define chMSG(desc) message(__FILE__ "(" \
		chSTR2(__LINE__) ") : reminder: " #desc)

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CDynaTableApp

BEGIN_MESSAGE_MAP(CDynaTableApp, CWinApp)
	//{{AFX_MSG_MAP(CDynaTableApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDynaTableApp construction

CDynaTableApp::CDynaTableApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// CDynaTableApp destruction

CDynaTableApp::~CDynaTableApp()
{
	// TODO: add destruction code here,	
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDynaTableApp object

CDynaTableApp theApp;

/////////////////////////////////////////////////////////////////////////////
// Dao_init must be called first, it starts the dao engine

__declspec(dllexport) int Dao_ws_open(void);
__declspec(dllexport) int Dao_ws_open(void)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		OutputDebugString("starting jet engine\n");

	//	Open TBdao named Workspace
		theApp.m_cDBEng.Open(NULL); 
		return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_ws_getname returns the name of the dao workspace

__declspec(dllexport) int Dao_ws_getname(char* ret,int siz);
__declspec(dllexport) int Dao_ws_getname(char* ret,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen()) {

			CString tmp=theApp.m_cDBEng.GetName();
			if (tmp.GetLength()<=siz) {
				strcpy(ret,(LPCTSTR)tmp);
				return OK;
			} else {
				return BUFFERSHORT;
			}
		} else {
			return WORKSPACENOTOPEN;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}
	
/////////////////////////////////////////////////////////////////////////////
// Dao_db_open opens a database

__declspec(dllexport) int Dao_db_open(char* mdb);
__declspec(dllexport) int Dao_db_open(char* mdb)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

#pragma chMSG(Protect against recreation when opening twice)

	TRY
	{
		OutputDebugString("opening database\n");

	//	If correct, this will also dispose the Recordsets in the database
		if (theApp.p_cDbs && theApp.p_cDbs->IsOpen())
			theApp.p_cDbs->Close();

	//	Create a database and open it.
		theApp.p_cDbs = new CDaoDatabase(&theApp.m_cDBEng);

	//	For JET Engine
		theApp.p_cDbs->Open(_T(mdb));
	
	//	For Direct ODBC dialog
		//theApp.p_cDbs->Open(_T(""),FALSE,FALSE,_T("ODBC;"));

#pragma chMSG(Protect against fault when database doesnt exist)
	
	//	Create a blank recordset.
		theApp.p_cRst = new CDaoRecordset(theApp.p_cDbs);
		return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_db_getname returns the (file)name of the database

__declspec(dllexport) int Dao_db_getname(char* ret,int siz);
__declspec(dllexport) int Dao_db_getname(char* ret,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {
			
			CString tmp=theApp.p_cDbs->GetName();
			if (tmp.GetLength()<=siz) {
				strcpy(ret,(LPCTSTR)tmp);
				return OK;
			} else {
				return BUFFERSHORT;
			}
		} else {
			return WORKSPACENOTOPEN;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_db_gettables returns the number of tables of the database

__declspec(dllexport) long Dao_db_gettables();
__declspec(dllexport) long Dao_db_gettables()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {
				return theApp.p_cDbs->GetTableDefCount();
		} else {
			return 0;
		}
	}
	CATCH_ALL(e)
	{
		DisplayDaoException((CDaoException*)e);
		return 0;
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_db_getqueries returns the number of queries of the database

__declspec(dllexport) long Dao_db_getqueries();
__declspec(dllexport) long Dao_db_getqueries()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {
				return theApp.p_cDbs->GetQueryDefCount();
		} else {
			return 0;
		}
	}
	CATCH_ALL(e)
	{
		DisplayDaoException((CDaoException*)e);
		return 0;
	}
	END_CATCH_ALL
}	

/////////////////////////////////////////////////////////////////////////////
// Dao_db_getrelations returns the number of relations of the database

__declspec(dllexport) long Dao_db_getrelations();
__declspec(dllexport) long Dao_db_getrelations()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {
				return theApp.p_cDbs->GetRelationCount();
		} else {
			return 0;
		}
	}
	CATCH_ALL(e)
	{
		DisplayDaoException((CDaoException*)e);
		return 0;
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_db_getversion returns the name of the database engine used

__declspec(dllexport) int Dao_db_getversion(char* ret,int siz);
__declspec(dllexport) int Dao_db_getversion(char* ret,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {

			CString tmp=theApp.p_cDbs->GetVersion();
			if (tmp.GetLength()<=siz) {
				strcpy(ret,(LPCTSTR)tmp);
				return OK;
			} else {
				return BUFFERSHORT;
			}
		} else {
			return WORKSPACENOTOPEN;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_db_cantransact returns if the database supports transactions

__declspec(dllexport) int Dao_db_cantransact();
__declspec(dllexport) int Dao_db_cantransact()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {
			if (theApp.p_cDbs->CanTransact())
				return OK;
			else 
				return NOTSUPPORTED;
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_db_canupdate returns  if the database supports can be updated

__declspec(dllexport) int Dao_db_canupdate();
__declspec(dllexport) int Dao_db_canupdate()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen()) {
			if (theApp.p_cDbs->CanUpdate())
				return OK;
			else 
				return NOTSUPPORTED;
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_query performs a sql query on the database, open in read/write dynaset mode

__declspec(dllexport) int Dao_rs_query(char* sql);
__declspec(dllexport) int Dao_rs_query(char* sql)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

#pragma chMSG(Allow type and options to be passed too)

	TRY
	{
		OutputDebugString("querying a database\n");

	//	Open recordset based on the passed SQL query.
		theApp.p_cRst->Open(dbOpenDynaset,_T(sql),dbDenyWrite|dbDenyRead); // was dbOpenSnapshot, dbReadOnly
	//	theApp.p_cRst->m_bCheckCacheForDirtyFields=false;	// only allowed true in DDX fieldexchange mode, 
															// false for dynamically binded tables?
	//	Populate Recordset by moving the pointer to the end.
		theApp.p_cRst->MoveLast();
		theApp.p_cRst->MoveFirst();
		return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_movefirst moves to first record of the query

__declspec(dllexport) int Dao_rs_movefirst();
__declspec(dllexport) int Dao_rs_movefirst()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		theApp.p_cRst->MoveFirst();
		
	//	After this it should always be BOF
	//	Test for BOF
		if (theApp.p_cRst->IsBOF())
			return OK;
		else
			return NOTBEGINOFFILE;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_moveprevious moves to previous record of the query

__declspec(dllexport) int Dao_rs_moveprevious();
__declspec(dllexport) int Dao_rs_moveprevious()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		theApp.p_cRst->MovePrev();

	//	Test for BOF
		if (theApp.p_cRst->IsBOF())
			return BEGINOFFILE;
		else
			return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_movenext moves to next record of the query

__declspec(dllexport) int Dao_rs_movenext();
__declspec(dllexport) int Dao_rs_movenext()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		theApp.p_cRst->MoveNext();

	//	Test for EOF
		if (theApp.p_cRst->IsEOF())
			return ENDOFFILE;
		else
			return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_movelast moves to last record of the query

__declspec(dllexport) int Dao_rs_movelast();
__declspec(dllexport) int Dao_rs_movelast()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		theApp.p_cRst->MoveLast();

	//	After this it should always be EOF
	//	Test for EOF
		if (theApp.p_cRst->IsEOF())
			return OK;
		else
			return NOTENDOFFILE;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_canappend returns if records can be appended to the query

__declspec(dllexport) int Dao_rs_canappend();
__declspec(dllexport) int Dao_rs_canappend()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanAppend())
				return OK;
			else 
				return NOTSUPPORTED;
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_canupdate returns if records can be written to the query

__declspec(dllexport) int Dao_rs_canupdate();
__declspec(dllexport) int Dao_rs_canupdate()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanUpdate())
				return OK;
			else 
				return NOTSUPPORTED;
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_canrestart returns if the query can be re-run

__declspec(dllexport) int Dao_rs_canrestart();
__declspec(dllexport) int Dao_rs_canrestart()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanRestart())
				return OK;
			else 
				return NOTSUPPORTED;
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_requery re-runs the query

__declspec(dllexport) int Dao_rs_requery();
__declspec(dllexport) int Dao_rs_requery()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanRestart()) {
				theApp.p_cRst->Requery();
				return OK;
			} else {
				return NOTSUPPORTED;
			}
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_edit puts current record in edit mode

__declspec(dllexport) int Dao_rs_edit();
__declspec(dllexport) int Dao_rs_edit()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		OutputDebugString("editing database\n");

		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanUpdate()) {
				OutputDebugString("entering edit mode\n");
				theApp.p_cRst->Edit();
				return OK;
			} else {
				return NOTSUPPORTED;
			}
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_addnew puts current record in edit mode for a new record

__declspec(dllexport) int Dao_rs_addnew();
__declspec(dllexport) int Dao_rs_addnew()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	//	AdvWorks.mdb
	//	fieldnames:LastName EmployeeID FirstName Title Extension WorkPhone 
	//	fieldtypes:Text     Long       Text      Text  Text      Text 

	TRY
	{
		OutputDebugString("extending database\n");

		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanAppend()) {
				OutputDebugString("entering AddNew mode\n");
				theApp.p_cRst->AddNew();
				return OK;
			} else {
				return NOTSUPPORTED;
			}
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_update updates current record

__declspec(dllexport) int Dao_rs_update();
__declspec(dllexport) int Dao_rs_update()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		OutputDebugString("updating a database\n");

		if (theApp.m_cDBEng.IsOpen() &&
			theApp.p_cDbs && theApp.p_cDbs->IsOpen() &&
			theApp.p_cRst && theApp.p_cRst->IsOpen()) {
			if (theApp.p_cRst->CanUpdate()) {

#pragma chMSG(Update still throws an unkown DAO errornr -5500 at us under win95)

				theApp.p_cRst->Update();

				return OK;
			} else {
				return NOTSUPPORTED;
			}
		} else
			return NOTOPEN;
	}
	CATCH_ALL(e)
	{
		if (e->IsKindOf(RUNTIME_CLASS(COleException))) {
			e->ReportError();
			return OLEEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CMemoryException))) {
			e->ReportError();
			return MEMEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CDaoException)))
			return DisplayDaoException((CDaoException*)e);

		return OTHEREXCEPTION;
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getnofields returns the number of database fields of the query

__declspec(dllexport) int Dao_rs_getnofields();
__declspec(dllexport) int Dao_rs_getnofields()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		return theApp.p_cRst->GetFieldCount();
	}
	CATCH_ALL(e)
	{
		DisplayDaoException((CDaoException*)e);
		return 0;
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getname returns the name of the cuurent SQL query

__declspec(dllexport) int Dao_rs_getname(char* val,int siz);
__declspec(dllexport) int Dao_rs_getname(char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.p_cRst->m_strFilter.GetLength()<=siz) {
		//	All went well, copy CString into return parameter.
			strcpy(val,(LPCTSTR)theApp.p_cRst->GetName());
			return OK;
		} else {
			return BUFFERSHORT;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getfilter returns the WHERE part of the SQL query

__declspec(dllexport) int Dao_rs_getfilter(char* val,int siz);
__declspec(dllexport) int Dao_rs_getfilter(char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.p_cRst->m_strFilter.GetLength()<=siz) {
		//	All went well, copy CString into return parameter.
			strcpy(val,(LPCTSTR)theApp.p_cRst->m_strFilter);
			return OK;
		} else {
			return BUFFERSHORT;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getsort returns the ORDER BY part of the SQL query

__declspec(dllexport) int Dao_rs_getsort(char* val,int siz);
__declspec(dllexport) int Dao_rs_getsort(char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.p_cRst->m_strSort.GetLength()<=siz) {
		//	All went well, copy CString into return parameter.
			strcpy(val,(LPCTSTR)theApp.p_cRst->m_strSort);
			return OK;
		} else {
			return BUFFERSHORT;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getsql returns the SQL query used

__declspec(dllexport) int Dao_rs_getsql(char* val,int siz);
__declspec(dllexport) int Dao_rs_getsql(char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.p_cRst->GetSQL().GetLength()<=siz) {
		//	All went well, copy CString into return parameter.
			strcpy(val,(LPCTSTR)theApp.p_cRst->GetSQL());
			return OK;
		} else {
			return BUFFERSHORT;
		}
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getfieldname returns the fieldname of a database field of the query

__declspec(dllexport) int Dao_rs_getfieldname(int fld,char* val,int siz);
__declspec(dllexport) int Dao_rs_getfieldname(int fld,char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (fld>=theApp.p_cRst->GetFieldCount() || fld<0)
		return INVALIDFIELDINDEX;

	CDaoFieldInfo fieldinfo;
	theApp.p_cRst->GetFieldInfo(fld,fieldinfo,AFX_DAO_PRIMARY_INFO);
	
	if (fieldinfo.m_strName.GetLength()<=siz) {
	//	All went well, copy CString into return parameter.
		strcpy(val,(LPCTSTR)fieldinfo.m_strName);
		return OK;
	} else {
		return BUFFERSHORT;
	}

}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getfieldtype returns the fieldtype of a database field of the query

__declspec(dllexport) int Dao_rs_getfieldtype(int fld,char* val,int siz);
__declspec(dllexport) int Dao_rs_getfieldtype(int fld,char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (fld>=theApp.p_cRst->GetFieldCount() || fld<0)
		return INVALIDFIELDINDEX;

	CDaoFieldInfo fieldinfo;
	theApp.p_cRst->GetFieldInfo(fld,fieldinfo,AFX_DAO_PRIMARY_INFO);
	
	CString tmp=CCrack::strFieldType(fieldinfo.m_nType);
	if (tmp.GetLength()<=siz) {
	//	All went well, copy CString into return parameter.
		strcpy(val,tmp);
		return OK;
	} else {
		return BUFFERSHORT;
	}
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getfieldsize returns the fieldsize of a database field of the query

__declspec(dllexport) long Dao_rs_getfieldsize(int fld);
__declspec(dllexport) long Dao_rs_getfieldsize(int fld)
{    
	TRY
	{
		AFX_MANAGE_STATE(AfxGetStaticModuleState());

		if (fld>=theApp.p_cRst->GetFieldCount() || fld<0)
			return 0;

		CDaoFieldInfo fieldinfo;
		theApp.p_cRst->GetFieldInfo(fld,fieldinfo,AFX_DAO_PRIMARY_INFO);
		return fieldinfo.m_lSize;
	}
	CATCH_ALL(e)
	{
		DisplayDaoException((CDaoException*)e);
		return 0;
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_getfieldvalue returns the value of a database field of the query

__declspec(dllexport) int Dao_rs_getfieldvalue(char* fld,char* val,int siz);
__declspec(dllexport) int Dao_rs_getfieldvalue(char* fld,char* val,int siz)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		if (theApp.p_cRst->GetRecordCount()) {
		//	Retrieve the value of the field requested.
		//	Dynamically allcoate a COleVariant.
			theApp.p_cRst->GetFieldValue(_T(fld),theApp.m_cFld);

   	    //	Turn the OLEvariant into a CString, a simple = won't work.
			CString tmp=CCrack::strVARIANT(theApp.m_cFld);
			
			if (tmp.GetLength()<=siz) {
			//	All went well, copy CString into return parameter.
				strcpy(val,(LPCTSTR)tmp);
				return OK;
			} else {
				return BUFFERSHORT;
			}
		} else {
			return NORECORDS;
		}
	}
	CATCH_ALL(e)
	{
		if (e->IsKindOf(RUNTIME_CLASS(COleException))) {
			e->ReportError();
			return OLEEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CMemoryException))) {
			e->ReportError();
			return MEMEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CDaoException)))
			return DisplayDaoException((CDaoException*)e);

		return OTHEREXCEPTION;
	}
	END_CATCH_ALL
}
	
/////////////////////////////////////////////////////////////////////////////
// Dao_rs_setfieldvalue sets the value of a database field of the query

__declspec(dllexport) int Dao_rs_setfieldvalue(char* fld,char* val);
__declspec(dllexport) int Dao_rs_setfieldvalue(char* fld,char* val)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{			
		CString     _fld;
		_fld.Format("%s",fld);
		
		if (theApp.p_cRst->CanUpdate()) {
				theApp.p_cRst->SetFieldValue((LPCTSTR)_fld,COleVariant((LPCTSTR)val,VT_BSTRT));
			return OK;
		}
		return NOTSUPPORTED;
	}
	CATCH_ALL(e)
	{
		if (e->IsKindOf(RUNTIME_CLASS(COleException))) {
			e->ReportError();
			return OLEEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CMemoryException))) {
			e->ReportError();
			return MEMEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CDaoException)))
			return DisplayDaoException((CDaoException*)e);

		return OTHEREXCEPTION;
	}
	END_CATCH_ALL
}
	

/////////////////////////////////////////////////////////////////////////////
// Dao_rs_find finds a record in a recordset (WHERE clause without WHERE)

__declspec(dllexport) int Dao_rs_find(long dir,char* fld);
__declspec(dllexport) int Dao_rs_find(long dir,char* fld)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{			
		OutputDebugString("searching a database\n");

		CString     _fld;
		_fld.Format("%s",fld);
		
		if (theApp.p_cRst->Find(dir,(LPCTSTR)_fld))
			return OK;
		else
			return NORECORDS;
	}
	CATCH_ALL(e)
	{
		if (e->IsKindOf(RUNTIME_CLASS(CMemoryException))) {
			e->ReportError();
			return MEMEXCEPTION;
		}
		if (e->IsKindOf(RUNTIME_CLASS(CDaoException)))
			return DisplayDaoException((CDaoException*)e);

		return OTHEREXCEPTION;
	}
	END_CATCH_ALL
}
	
/////////////////////////////////////////////////////////////////////////////
// Dao_db_close closes the database (and recordset)

__declspec(dllexport) int Dao_db_close(void);
__declspec(dllexport) int Dao_db_close(void)
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		OutputDebugString("closing database\n");

	//	Close both Database and Recordset by hand.
		if (theApp.p_cRst && theApp.p_cRst->IsOpen())
			theApp.p_cRst->Close();

		if (theApp.p_cDbs && theApp.p_cDbs->IsOpen())
			theApp.p_cDbs->Close();
		
		return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// Dao_shutdown closes the workspace

__declspec(dllexport) int Dao_ws_close();
__declspec(dllexport) int Dao_ws_close()
{    
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	TRY
	{
		OutputDebugString("closing workspace\n");

	//	Close workspace if it was open and all thats created in it.
		if (theApp.m_cDBEng.IsOpen()) {
			theApp.m_cDBEng.Close();
		}

	//	Important to call this before the dll's theApp gets destructed.
		AfxDaoTerm();
		return OK;
	}
	CATCH_ALL(e)
	{
		return DisplayDaoException((CDaoException*)e);
	}
	END_CATCH_ALL
}

/////////////////////////////////////////////////////////////////////////////
// DisplayDaoException catches & displays CDao faults

int DisplayDaoException(CDaoException* e)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	CString strMsg;
	if (e->m_pErrorInfo!=NULL)
	{
		strMsg.Format(
			_T("%s   (%ld)\n\n")
			_T("Would you like to see help?"),
			(LPCTSTR)e->m_pErrorInfo->m_strDescription,
			e->m_pErrorInfo->m_lErrorCode);

		if (AfxMessageBox(strMsg, MB_YESNO) == IDYES)
		{
			WinHelp(GetDesktopWindow(),
					e->m_pErrorInfo->m_strHelpFile,
					HELP_CONTEXT,
					e->m_pErrorInfo->m_lHelpContext);
		}

		return e->m_pErrorInfo->m_lErrorCode;
	}
	else
	{
		strMsg.Format(
			_T("ERROR:CDaoException\n\n")
			_T("SCODE_CODE		=%d\n")	
			_T("SCODE_FACILITY	=%d\n")	
			_T("SCODE_SEVERITY	=%d\n")	
			_T("ResultFromScode	=%d\n"),
			SCODE_CODE		(e->m_scode),
			SCODE_FACILITY	(e->m_scode),
			SCODE_SEVERITY	(e->m_scode),
			ResultFromScode (e->m_scode));
		AfxMessageBox(strMsg);

		return UNKNOWNERROR;
	}
}

//	Sample code to check the exception type
//	CMemoryException 
//	CRuntimeClass* prt = e->GetRuntimeClass();
//	AfxMessageBox(prt->m_lpszClassName); //Should be CDaoException
//	theApp.p_cRst->m_bCheckCacheForDirtyFields=false; 

